# aeriOS LLO NATS Broker

A NATS broker is used by all the aeriOS LLO types (expect the LLO K8s) to stablish asynchronous communication between the LLO Operator 
(deployed in the K8s cluster of the domain) and the LLO Controller (deployed in each IE that must be controlled by this LLO type).

**The same NATS broker can be used by multiple LLOs**, so it is not necessary to deploy a new NATS broker for each LLO type.

## Helm chart

A custom and simple Helm chart is provided to deploy the NATS broker in the K8s cluster of the domain, in which the K8s Operators of the different LLOs should be installed. 
The chart is located in the `helm-chart` directory.

This chart uses by default the port 30222 (as NodePort) to expose the NATS service, so the NATS broker will be available at `nats://<k8s-node-ip>:30222`.

```bash
helm repo add eclipse-aerios https://eclipse-aerios.github.io/resources/charts
```

```bash
helm install llo-nats eclipse-aerios/llo-nats --debug
```